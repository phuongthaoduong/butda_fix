"""
AgentHub Builtin Tools

Provides ready-to-use tools for common tasks like web search, file operations,
and more.

Available Tools:
- web_search: Web search with AI-powered query rewriting
"""
