"""CLI commands package for AgentHub."""

from .agent import agent

__all__ = ["agent"]
